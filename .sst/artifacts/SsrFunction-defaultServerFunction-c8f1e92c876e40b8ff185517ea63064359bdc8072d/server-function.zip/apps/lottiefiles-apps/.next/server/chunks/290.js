exports.id=290,exports.ids=[290],exports.modules={4378:(e,t,s)=>{Promise.resolve().then(s.t.bind(s,730,23))},1957:(e,t,s)=>{Promise.resolve().then(s.t.bind(s,4424,23)),Promise.resolve().then(s.t.bind(s,7752,23)),Promise.resolve().then(s.t.bind(s,5275,23)),Promise.resolve().then(s.t.bind(s,9842,23)),Promise.resolve().then(s.t.bind(s,1633,23)),Promise.resolve().then(s.t.bind(s,9224,23))},4457:(e,t,s)=>{"use strict";s.d(t,{AnimationCard:()=>l});var r=s(3227),a=s(649);function i({header:e,body:t,description:s,footer:a,className:i="",...l}){return(0,r.jsxs)("div",{className:`${i}`,...l,children:[e,t,s,a]})}let l=({className:e="",header:t,body:s,description:l,footer:o,url:n,...c})=>r.jsx(a.default,{href:"/animation",children:r.jsx(i,{className:`rounded-xl flex flex-col justify-between h-full bg-gray-100 dark:bg-gray-700 hover:cursor-pointer ${e}`,header:r.jsx("div",{className:"aspect-square grid items-center bg-gray-100 dark:bg-gray-700",children:t}),body:s,description:l,footer:r.jsx("div",{className:"p-4 bg-white dark:bg-gray-900",children:o}),onClick:()=>{localStorage.setItem("currentAnimationUrl",n)},...c})})},1897:(e,t,s)=>{"use strict";s.r(t),s.d(t,{BackNav:()=>l});var r=s(3227),a=s(6376),i=s(1043);let l=()=>{let e=(0,i.useRouter)();return r.jsx(a.Button,{className:"bg-gray-200 dark:bg-gray-700 px-4 py-2 rounded-lg",onClick:()=>e.back(),children:"Go back"})}},8248:(e,t,s)=>{"use strict";s.r(t),s.d(t,{DotLottiePlayer:()=>l});var r=s(3227),a=s(3405),i=s(3677);let l=({src:e,...t})=>{let[s,l]=(0,i.useState)();return r.jsx(r.Fragment,{children:r.jsx(a.nI,{src:e,autoplay:!0,loop:!0,dotLottieRefCallback:e=>{console.log(">>> dotLottieRef",e)},...t})})}},104:(e,t,s)=>{"use strict";s.r(t),s.d(t,{LottiePlayer:()=>o});var r=s(3227),a=s(3271),i=s(8248);let l=({src:e,showControls:t,controlProps:s,playerProps:i})=>r.jsx(a.J5,{autoplay:!0,loop:!0,src:e,...i,children:t&&r.jsx(a.ZX,{transparentTheme:!0,visible:!0,buttons:["play","repeat","frame","debug"],...s})}),o=({src:e,showControls:t,controlProps:s,playerProps:a,...o})=>e?r.jsx("div",{...o,children:e.endsWith(".json")?r.jsx(l,{src:e,showControls:t,controlProps:s,playerProps:a}):r.jsx(i.DotLottiePlayer,{src:e})}):null},3861:(e,t,s)=>{"use strict";s.r(t),s.d(t,{LottiePlayerPage:()=>l});var r=s(3227),a=s(104),i=s(3677);function l(){let e=function(e){let[t,s]=(0,i.useState)(null);return t}(0);return e?r.jsx(a.LottiePlayer,{src:e,className:"max-w-md mx-auto",playerProps:{lottieRef:e=>{console.log(">>> ref",e)}},showControls:!0,controlProps:{className:"bg-gray-700"}}):null}},5159:(e,t,s)=>{"use strict";s.r(t),s.d(t,{Modal:()=>n});var r=s(3227),a=s(9700),i=s(2969),l=s(6376),o=s(3677);let n=({children:e,title:t,cta:s,onClose:n})=>{let[c,d]=(0,o.useState)(!0);function u(){n&&n(),d(!1)}return r.jsx(a.u,{appear:!0,show:c,children:r.jsx(i.Vq,{as:"div",className:"relative z-10 focus:outline-none",onClose:u,children:r.jsx("div",{className:"fixed inset-0 z-10 w-screen overflow-y-auto",children:r.jsx("div",{className:"flex min-h-full items-center justify-center p-4",children:r.jsx(a.x,{enter:"ease-out duration-300",enterFrom:"opacity-0 transform-[scale(95%)]",enterTo:"opacity-100 transform-[scale(100%)]",leave:"ease-in duration-200",leaveFrom:"opacity-100 transform-[scale(100%)]",leaveTo:"opacity-0 transform-[scale(95%)]",children:(0,r.jsxs)(i.EM,{className:"dark:bg-gray-100 w-full max-w-md rounded-xl p-6 backdrop-blur-2xl",children:[r.jsx(i.$N,{as:"h3",className:"text-base/7 font-medium text-white",children:t}),e,s&&r.jsx("div",{className:"mt-4",children:r.jsx(l.Button,{className:"inline-flex items-center gap-2 rounded-md bg-gray-700 py-1.5 px-3 text-sm/6 font-semibold text-white shadow-inner shadow-white/10 focus:outline-none data-[hover]:bg-gray-600 data-[open]:bg-gray-700 data-[focus]:outline-1 data-[focus]:outline-white",onClick:u,children:s?.label})})]})})})})})})}},7718:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>p,metadata:()=>c,viewport:()=>d});var r=s(9013);s(1672);var a=s(7043);let i="Lottie Shop",l="Lottie Shop",o="%s - PWA App",n="Find cool animations. Works offline too...",c={applicationName:i,title:{default:l,template:o},description:n,appleWebApp:{capable:!0,statusBarStyle:"default",title:l},formatDetection:{telephone:!1},openGraph:{type:"website",siteName:i,title:{default:l,template:o},description:n},twitter:{card:"summary",title:{default:l,template:o},description:n}},d={themeColor:"#FFFFFF"},u=()=>r.jsx("nav",{className:"text-xl px-4 md:px-8 py-4 md:py-8 flex gap-2 shadow-xl sticky top-0 bg-white dark:bg-gray-900 z-10",children:(0,r.jsxs)("a",{href:"/",className:"flex gap-4 items-center",children:[r.jsx(a.default,{src:"/icons/web/apple-touch-icon.png",alt:"Lottie Shop",width:32,height:32}),"Lottie Shop"]})});function p({children:e}){return(0,r.jsxs)("html",{lang:"en",children:[r.jsx("head",{}),(0,r.jsxs)("body",{children:[r.jsx(u,{}),r.jsx("main",{className:"px-4 md:px-16 lg:px-32 xl:px-128 py-8",children:e})]})]})}},891:(e,t,s)=>{"use strict";s.d(t,{vK:()=>y,El:()=>b,Vu:()=>g,j7:()=>S});var r=s(9013),a=s(8393);let{getClient:i}=(0,s(1827).m)(()=>(0,a.eI)({url:"https://graphql.lottiefiles.com/2022-08",exchanges:[a.HG,a.Ek]})),l=(0,a.Ps)`
  {
    featuredPublicAnimations(filters: {}) {
      totalCount
      pageInfo {
        endCursor
        hasNextPage
        hasPreviousPage
        startCursor
      }
      edges {
        cursor
        node {
          bgColor
          commentsCount
          createdAt
          createdByUserId
          description
          downloads
          gifFileSize
          gifUrl
          id
          imageFileSize
          imageFrame
          imageUrl
          isLiked
          likesCount
          lottieFileSize
          lottieFileType
          lottieUrl
          jsonUrl
          lottieVersion
          name
          publishedAt
          slug
          sourceFileName
          sourceFileSize
          sourceFileType
          sourceFileUrl
          sourceName
          sourceVersion
          speed
          status
          updatedAt
          url
          videoFileSize
          videoUrl
          isCanvaCompatible
        }
      }
    }
  }
`;async function o(){let e=await i().query(l,{});return e?.data?.featuredPublicAnimations?.edges}var n=s(3189);let c=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/AnimationCard.tsx`),{__esModule:d,$$typeof:u}=c;c.default;let p=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/AnimationCard.tsx#AnimationCard`),m=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/LottiePlayer.tsx`),{__esModule:x,$$typeof:f}=m;m.default;let g=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/LottiePlayer.tsx#LottiePlayer`);async function h(){let e=await o();return r.jsx(r.Fragment,{children:e?.map(e=>r.jsx(p,{className:"dark:bg-gray-700 rounded-xl overflow-hidden shadow-xl",url:`${e.node.jsonUrl}`,header:r.jsx(g,{src:e.node.jsonUrl,className:"bg-gray-100 dark:bg-gray-700"}),footer:r.jsx("h2",{className:"truncate",children:e.node.name})},e.node.id))})}async function y(){return r.jsx(r.Fragment,{children:r.jsx(h,{})})}let v=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/BackNav.tsx`),{__esModule:j,$$typeof:w}=v;v.default;let b=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/BackNav.tsx#BackNav`),P=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/LottiePlayerPage.tsx`),{__esModule:k,$$typeof:N}=P;P.default;let S=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/LottiePlayerPage.tsx#LottiePlayerPage`),F=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/Modal.tsx`),{__esModule:U,$$typeof:L}=F;F.default,(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/Modal.tsx#Modal`);let C=(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/DotLottiePlayer.tsx`),{__esModule:$,$$typeof:A}=C;C.default,(0,n.createProxy)(String.raw`/Users/juliuscarvajal/work/interviews/lottiefiles/lottiefiles-apps/libs/components/src/DotLottiePlayer.tsx#DotLottiePlayer`)},1672:()=>{}};